%% accuracy.m 
% Define Evaluation Index
function [ acc ] = accuracy( a, y )

end
