%% cost.m
% Define Cost Function
%% Step 4: Define Cost Function
function [J] = cost(a, y)

end


