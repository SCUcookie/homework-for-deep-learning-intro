clear;
clc;

%% Step 1: Data Preparation 
 
% loading dataset
load mnist_small_matlab.mat
% trainData: a matrix with size of 28x28x10000   
% trainLabels: a matrix with size of 10x10000
% testData: a matrix with size of 28x28x2000
% testLabels: a matrix with size of 10x2000


train_size = 10000; % number of training samples
% input in the 1st layer 
X_train = reshape(trainData, 784, train_size); 


test_size = 2000; % number of testing samples
% external input in the 1st layer 
X_test = reshape(testData, 784, test_size); 

%% Step 2: Design Network Architecture
% define number of layers
L = ; 
% define number of neurons in each layer 
layer_size = 
          
%% Step 3: Initial Parameters

% initialize weights in each layer with Gaussian distribution
for l = 1:L-1
    w{l} = 0.1 * randn(layer_size(l+1,1), sum(layer_size(l,:)));
end
 
alpha = 0.005; % initialize learning rate 

%% Step 4: Define Cost Function
% cost function is defined in cost.m

%% Step 5: Define Evaluation Index
% accuracy defined in accuracy.m

%% Step 6: Train the Network
J = []; % array to store cost of each mini batch
Acc = []; % array to store accuracy of each mini batch
max_epoch = 25; % number of training epoch
mini_batch = 100; % number of sample of each mini batch

figure % plot the cost
for iter=1:max_epoch
    % randomly permute the indexes of samples in training set
idxs = randperm(train_size); 
% for each mini-batch
for k = 1:ceil(train_size/mini_batch)
    % prepare internal inputs in 1st layer denoted by a{1}
    
    start_idx = (k-1)*mini_batch+1;          % start index of kth mini-batch
    end_idx = min(k*mini_batch, train_size); % end index of kth mini-batch
    fprintf('start_idx is %d\n',start_idx);
    fprintf('end_idx is %d\n', end_idx);
	a{1} = X_train(:,idxs(start_idx:end_idx));
    % prepare labels
    y = trainLabels(:, idxs(start_idx:end_idx));
    
        % your code blow
        % forward computation
        
 
        % Compute delta of last layer
         
 
        % backward computation
        
 
        % update weight 
        
        % end your code

        % training cost on training batch
        J = [J 1/mini_batch*sum(cost(a{L}, y))];
        Acc =[Acc accuracy(a{L}, y)]; 
        % plot training error 
        plot(J);
        pause(0.000001);
    end
end 
% end training
% plot accuracy
figure
plot(Acc);

%% Step 7: Test the Network
%test on training set
a{1} = X_train;
% your code blow

% end your code
train_acc = accuracy(a{L}, trainLabels);
fprintf('Accuracy on training dataset is %f%%\n', train_acc*100);

%test on testing set
a{1} = X_test;
for l = 1:L-1
   a{l+1} = fc(w{l}, a{l});
end
test_acc = accuracy(a{L}, testLabels);
fprintf('Accuracy on testing dataset is %f%%\n', test_acc*100);

%% Step 8: Store the Network Parameters
save model.mat w layer_size

